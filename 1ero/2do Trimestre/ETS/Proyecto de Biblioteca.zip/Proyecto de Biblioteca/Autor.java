import java.util.Date;



class Autor {
    String nombre;
    Date fechaNac;
    String nacionalidad;
}
