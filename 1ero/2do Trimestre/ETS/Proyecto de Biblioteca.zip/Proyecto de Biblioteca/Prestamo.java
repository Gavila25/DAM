import java.util.Date;


class Prestamo {
    int fechaLimite;
    Date fechaPrestamo;
}
