

class CopiaLibro {
    enum estadoLibro={"BIBLIOTECA", "PRESTADO", "RETRASO", "REPARACION"};
    String nombre;
    int ID;
    String Estado=CopiaLibro.estadoLibro;
}
