

class Editorial {
    String nombre;
}
