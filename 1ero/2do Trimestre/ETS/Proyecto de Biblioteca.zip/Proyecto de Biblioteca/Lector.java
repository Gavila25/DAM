class Lector {
    String nombre;
}
