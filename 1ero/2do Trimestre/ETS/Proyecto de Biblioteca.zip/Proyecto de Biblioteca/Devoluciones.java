import java.util.Date;

class Devoluciones{
    Date fechaDevolución;

}