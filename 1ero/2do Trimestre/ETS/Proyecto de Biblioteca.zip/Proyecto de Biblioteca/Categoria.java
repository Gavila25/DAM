package 1ero.2do Trimestre.ETS.Proyecto de Biblioteca;

class Categoria {
    enum categoriaLibro{"NOVELA","TEATRO","POESIA","ENSAYO"};
    String categoria=Categoria.categoriaLibro;
}
